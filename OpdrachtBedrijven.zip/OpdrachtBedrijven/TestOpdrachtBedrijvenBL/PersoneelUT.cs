﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestOpdrachtBedrijvenBL
{
    public class PersoneelUT
    {
        [Theory]
        public void Test_Id_valid(int id)
        {
            //TODO check if id is valid
        }
        [Theory]
        public void Test_Id_invalid(int id)
        {
            //TODO check if id is invalid
        }
    }
}
